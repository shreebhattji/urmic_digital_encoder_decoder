  <footer class="site-footer">
    Crafted with ❤️ by ShreeBhattJi ( Devdatt Bhatt ) - Support +91-8000-74-1919
  </footer>

</body>
</html>