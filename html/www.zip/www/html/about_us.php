<?php include 'header.php'; ?>

<div class="containerindex">
    <div class="grid">
        <div class="card wide">
        </div>
    </div>
</div>
<br>
<br>
<?php include 'footer.php'; ?>
