<?php include 'static.php'; ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Full-page layout — static header & footer</title>
    <script src="chart.js"></script>
    <style>
        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        :root {
            --header-h: 64px;
            --header-bg: linear-gradient(90deg, #1e293b, #0f172a);
            --header-color: #e6eef8;
            --footer-h: 52px;
            --footer-bg: linear-gradient(90deg, #1e293b, #0f172a);
            --footer-color: #e6eef8;
        }

        main {
            height: calc(100vh - var(--header-h) - var(--footer-h));
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            padding: 16px;
            padding-bottom: calc(var(--footer-h) + 16px);
        }

        .container {
            max-width: 1100px;
            margin: 12px auto;
            padding: 12px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(2, 6, 23, 0.06);
        }

        .containerindex {
            max-width: 1100px;
            margin: 12px auto;
            padding: 12px;
            padding-top: 63px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(2, 6, 23, 0.06);
        }

        .grid {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: flex-start;
        }

        .card {
            flex: 1 1 43%;
            min-width: 300px;
            display: flex;
            flex-direction: column;
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.03), rgba(255, 255, 255, 0.02));
            border-radius: 10px;
            padding: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
        }

        .card.wide {
            flex-basis: 100%;
        }

        .card h3 {
            margin: 0 0 8px 0;
            font-size: 1.3rem;
        }

        .card .chart-wrap {
            flex: 1 1 auto;
            min-height: 180px;
            height: 247px;
            position: relative;
        }

        .card canvas {
            display: block;
            width: 100% !important;
            height: 100% !important;
        }

        .status-row {
            margin-top: 12px;
            color: #9fb2d6;
            display: flex;
            justify-content: space-between;
            font-size: 13px;
        }

        @media (max-width: 640px) {
            :root {
                --header-h: 56px;
                --footer-h: 56px;
            }


            main {
                padding: 10px;
            }

            .card {
                flex: 1 1 100%;
                min-width: auto;
            }

            .card .chart-wrap {
                height: 220px;
                min-height: 160px;
            }
        }

        .site-footer {
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            height: var(--footer-h);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 32px;
            background: var(--footer-bg);
            color: var(--footer-color);
            z-index: 999;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.18);
            font-size: 14px;
        }

        .site-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: var(--footer-h, 73px);

            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 48px;
            margin-bottom: 57px;
            background: linear-gradient(90deg, #0f172a, #1e293b);
            color: #e6eef8;
            font-weight: bold;

            font-size: 17px;
            font-weight: 500;
            letter-spacing: 0.4px;

            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);

            z-index: 999;
            transition: all 0.3s ease;
        }


        .site-header nav a {
            margin-left: 28px;
            color: #e6eef8;
            text-decoration: none;
            transition: color 0.3s ease;
            font-weight: bold;
        }

        .site-header nav a:hover {
            color: #38bdf8;
        }

        .site-header.scrolled {
            background: rgba(15, 23, 42, 0.9);
            backdrop-filter: blur(6px);
        }

        .dropdown-container {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 7px;
        }

        .dropdown-label {
            font-size: 23px;
            font-weight: 500;
            color: #1e293b;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            color: black;
            padding: 12px 40px 12px 16px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .dropdown select:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.25);
        }

        .dropdown::after {
            content: "▼";
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
            color: white;
            font-size: 12px;
        }

        .dropdown select option {
            background: #ffffff;
            color: #1e293b;
            padding: 7px;
        }

        .input-container {
            display: flex;
            flex-wrap: nowrap;
            gap: 10px;
        }


        .input-group {
            position: relative;
            width: auto;
            min-width: 333px;
            margin: 5px;
        }

        .input-group input {
            width: 100%;
            padding: 11px 11px;
            font-size: 13px;
            border: 2px solid #cbd5e1;
            border-radius: 8px;
            outline: none;
            background: white;
            transition: border-color 0.3s ease;
            margin: 5px;
        }

        .input-group input:focus {
            border-color: #3b82f6;
        }

        .input-group label {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 16px;
            pointer-events: none;
            transition: 0.3s ease all;
            background: white;
            padding: 0 4px;
        }

        .input-group input:focus+label,
        .input-group input:not(:placeholder-shown)+label {
            top: -6px;
            left: 8px;
            font-size: 12px;
            color: #3b82f6;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }

        .checkbox-group input[type="checkbox"] {
            accent-color: #3b82f6;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .checkbox-group label {
            font-size: 14px;
            color: #1e293b;
            cursor: pointer;
        }

        .red-btn {
            background-color: red;
            color: white;
            font-weight: bold;
            /* bold text */
            padding: 10px 20px;
            border: none;
            width: 33%;
            border-radius: 7px;
            cursor: pointer;
        }

        .red-btn:hover {
            background-color: darkred;
        }

        .form-center {
            text-align: center;
            /* center button */
        }
    </style>
</head>

<body>
    <header class="site-header">
        Encoder / Decoder
        <nav aria-label="Top navigation">
            <a href="index.php">Monitor</a>
            <a href="input.php">Input</a>
            <a href="output.php">Output</a>
            <a href="network.php">Network</a>
            <a href="firewall.php">Firewall</a>
            <a href="firmware.php">Firmware</a>
            <a href="about_us.php">About Us</a>
        </nav>
    </header>