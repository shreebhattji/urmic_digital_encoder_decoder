  <footer class="site-footer">
    Crafted with ❤️ by ShreeBhattJi ( Devdatt Bhatt ) &nbsp;•&nbsp;  +91-8000-74-1919
  </footer>

</body>
</html>
<!--
Urmi you happy me happy licence

Copyright (c) 2026 shreebhattji

License text:
https://github.com/shreebhattji/Urmi/blob/main/licence.md
-->
